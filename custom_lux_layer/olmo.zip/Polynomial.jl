"""
Arguments: x, y: data as 1D Vectors of size N, preallocated
"""
function generate_polynomial(N, degree, x, y)
    # for 1D polynomials
    #IJ = [(i,j) for i in Ix for j in Iy if i + j < (degree+1)]
    #I = [i[1] for i in IJ]
    #J = [i[2] for i in IJ]

    if degree == 2
        IJ = [(0,0), (1,0), (2,0), (0,1), (0,2), (1,1)]
        I = (0,1,2,0,0,1)
        J = (0,0,0,1,2,1)
    elseif degree == 3
        IJ = [(0,0), (1,0), (0,1), (2,0), (1,1), (0,2), (3,0), (2,1), (1,2), (0,3)]
        I = (0, 1, 0, 2, 1, 0, 3, 2, 1, 0)
        J = (0, 0, 1, 0, 1, 2, 0, 1, 2, 3)
    elseif degree == 4
        IJ = [(0,0), (1,0), (0,1), (2,0), (1,1), (0,2), (3,0), (2,1), (1,2), (0,3), (4,0), (3,1), (2,2), (1,3), (0,4)]
        I = (0, 1, 0, 2, 1, 0, 3, 2, 1, 0, 4, 3, 2, 1, 0)
        J = (0, 0, 1, 0, 1, 2, 0, 1, 2, 3, 0, 1, 2, 3, 4)
    else
        println("Degree greater than 3 not implemented")
    end

    # Construct a polynomial in x and y, according to the indices listed in I
     Poly(coef) = @tullio poly[i] := coef[j] * x[i]^I[j] * y[i]^J[j] grad=Dual nograd=x nograd=y nograd=I nograd=J
     return Poly
end

function test_polynomial_generation()
	N = 10_000
	degree =20 
    x = rand(N)
    y = rand(N)
    nb_terms = Int((degree+1)*(degree+2) / 2.)
    coef = rand(nb_terms)
	poly = generate_polynomial(N, degree, x, y);
	@time poly(coef)
	loss = x -> sum(poly(x).^2)
    coef = rand(nb_terms)
	@time Zygote.gradient(loss, coef)
	println(length(coef))
end

# test_polynomial_generation()
